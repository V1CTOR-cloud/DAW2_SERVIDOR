<?php
class View {
    public function vista($greetings, $time){
        echo "$greetings: $time";
    }
}
?>