<?php
class sayingView {
    public function sayingMostrar($phrase){
        echo $phrase;
    }
}
?>