<?php

function getCurrentTime(){
    return date("h:i:s", time());
}

?>