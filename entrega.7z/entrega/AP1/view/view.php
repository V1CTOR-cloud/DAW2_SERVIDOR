<?php
function view($greetings, $time){
    echo "$greetings: $time";
}
?>