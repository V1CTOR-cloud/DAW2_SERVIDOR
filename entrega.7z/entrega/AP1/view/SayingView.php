<?php
function sayingView($phrase){
    echo $phrase;
}
?>